class Solution {
public:
   
    int getHeight(TreeNode* root) {
        if (!root) return 0;
        int left = getHeight(root->left);
        if (left == -1) return -1;
        int right = getHeight(root->right);
        if (right == -1) return -1;

        if (abs(left - right) > 1) return -1;
        return 1 + max(left, right);
    }

    bool checkbalance(TreeNode* root) {
        return getHeight(root) != -1;
    }

   
    void inorder(TreeNode* root, vector<int>& vals) {
        if (!root) return;
        inorder(root->left, vals);
        vals.push_back(root->val);
        inorder(root->right, vals);
    }

   
    TreeNode* buildBalancedBST(vector<int>& vals, int start, int end) {
        if (start > end) return nullptr;
        int mid = (start + end) / 2;
        TreeNode* root = new TreeNode(vals[mid]);
        root->left = buildBalancedBST(vals, start, mid - 1);
        root->right = buildBalancedBST(vals, mid + 1, end);
        return root;
    }

    TreeNode* balanceBST(TreeNode* root) {
        if (checkbalance(root)) {
            return root;
        } else {
          
            while (!checkbalance(root)) {
                vector<int> vals;
                inorder(root, vals);  
                root = buildBalancedBST(vals, 0, vals.size() - 1); 
            }
            return root;
        }
    }
};
