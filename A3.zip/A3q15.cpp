class Solution {
public:
    Node* construct(vector<vector<int>>& grid) {
        return build(grid, 0, 0, grid.size());
    }

private:
    Node* build(vector<vector<int>>& grid, int r, int c, int size) {
        // Check if all values in this region are the same
        bool same = true;
        int val = grid[r][c];

        for (int i = r; i < r + size; ++i) {
            for (int j = c; j < c + size; ++j) {
                if (grid[i][j] != val) {
                    same = false;
                    break;
                }
            }
            if (!same) break;
        }

        if (same) {
            return new Node(val == 1, true);  // val is either 1 or 0
        }

        int newSize = size / 2;
        Node* topLeft = build(grid, r, c, newSize);
        Node* topRight = build(grid, r, c + newSize, newSize);
        Node* bottomLeft = build(grid, r + newSize, c, newSize);
        Node* bottomRight = build(grid, r + newSize, c + newSize, newSize);

        return new Node(true, false, topLeft, topRight, bottomLeft, bottomRight);
    }
};
