class Solution {
public:
    TreeNode* insertIntoBST(TreeNode* root, int val) {
        
       
       if(root==nullptr){
            TreeNode* wo= new TreeNode();
            wo->val=val;
            wo->left=nullptr;
            wo->right=nullptr;
            return wo;
        }
        else if(val<root->val && root->left==nullptr){
            TreeNode* wo= new TreeNode();
            wo->val=val;
            root->left=wo;
            wo->left=nullptr;
            wo->right=nullptr;
           
        }
        else if(val>root->val && root->right==nullptr){
               TreeNode* wo= new TreeNode();
            wo->val=val;
            root->right=wo;
            wo->left=nullptr;
            wo->right=nullptr;
            
        }
        else if(val<root->val){
            insertIntoBST(root->left,val);
        }
        else{
             insertIntoBST(root->right,val);
        }
        return root;
    }
};