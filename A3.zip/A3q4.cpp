#include<iostream>
#include<vector>
using namespace std;
int main(){
int n;
cin>>n;
vector<vector<int>> arr;
vector<int> row;
int heightfy;
int left,right,height;
for(int i=0;i<n;i++){
cin>>left>>right>>height;
row.push_back(left,height,right);
arr.push_back(row);
}
sort(arr.begin(),arr.end());
vector<vector<int>> yo;
for(int i=0;i<arr.size();i++){
for(int j=i+1;j<yosize();j++){
if(arr[i].first>yo[j].third){
yo.push_back(arr[i]);
}
else if(arr[i].frist>=yo[j].first && arr[i].third<=yo[j].third && arr[i].second>yo[j].second){
yo[j]third=arr[i].first;
yo.push_back(arr[i]);
yo.push_back(arr[i].third,yo[j].second,yo[j].third);
}
else if(arr[i].frist>=yo[j].first && arr[i].third>yo[j].third){
if(arr[i].second>yo[j].second){
yo[j].third=arr[i].first;
yo.push_back(arr[i]);
}
else{
yo.push_back(yo[j].third,arr[i].second,arr[j].third)
}
}
}
int sum=0;
for(auto i:yo){
sum+=(yo[i].third-yo[i].first)*yo[i].second
}
return 0;
}
