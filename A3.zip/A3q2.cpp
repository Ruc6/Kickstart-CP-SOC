class Solution {
  public:
    // Function to count inversions in the array.
    int inversionCount(vector<int> arr) {
        int n = arr.size();
        int mid = n / 2;
        int count = 0;

        // Count inversions in left half
        for (int i = 0; i < mid; i++) {
            for (int j = i + 1; j < mid; j++) {
                if (arr[j] < arr[i]) count++;
            }
        }

        // Count inversions in right half
        for (int i = mid; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[i]) count++;
            }
        }

        // Sort left half
        sort(arr.begin(), arr.begin() + mid);

        // Sort right half
        sort(arr.begin() + mid, arr.end());

        // Count cross inversions between left and right halves
        for (int i = mid; i < n; i++) {
            for (int j = 0; j < mid; j++) {
                if (arr[j] > arr[i]) {
                    count += mid - j;
                    break;
                }
            }
        }

        return count;
    }
};