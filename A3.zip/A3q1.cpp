#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int getinterval() {
    int n;
    cin >> n;
    vector<pair<int, int>> intervals;

    for (int i = 0; i < n; i++) {
        int start, end;
        cin >> start >> end;
        intervals.push_back({start, end});
    }
    sort(intervals.begin(), intervals.end());
    vector<pair<int, int>> merged;
    for (auto interval : intervals) {
        if (merged.empty() || merged.back().second < interval.first) {
            merged.push_back(interval);
        } else {
            merged.back().second = max(merged.back().second, interval.second);
        }
    }
    int total = 0;
    for (auto x : merged) {
        total += x.second - x.first;
    }

    return total;
}

int main() {
    cout << getinterval() << endl;
    return 0;
}


