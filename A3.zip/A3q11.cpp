class Solution {
public:
    vector<int> postorderTraversal(TreeNode* root) {
          vector<int> yo;
        if(root==nullptr){
            return yo;
        }
       vector<int> yes;
        yes=postorderTraversal(root->left);
        for(int i=0;i<yes.size();i++){
            yo.push_back(yes[i]);
        }
        yes.clear();
        yes=postorderTraversal(root->right);
         for(int i=0;i<yes.size();i++){
            yo.push_back(yes[i]);
        }
         yo.push_back(root->val);
        return yo;
    }
};