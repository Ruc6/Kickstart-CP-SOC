class Solution {
public:
    int result; 
    int count;  
    void reverseInorder(Node* root, int k) {
        if (root == nullptr) {
            return;
        }

        reverseInorder(root->right, k);

       
        count++;
        if (count == k) {
            result = root->data;
            return;
        }

        if (count < k) { 
            reverseInorder(root->left, k);
        }
    }

    int kthLargest(Node *root, int k) {
        result = -1; 
        count = 0;   

        reverseInorder(root, k);
        return result;
    }
};