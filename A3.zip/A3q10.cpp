class Solution {
public:
    vector<int> preorderTraversal(TreeNode* root) {
         vector<int> yo;
        if(root==nullptr){
            return yo;
        }
        yo.push_back(root->val);
        vector<int> yes;
        yes=preorderTraversal(root->left);
        for(int i=0;i<yes.size();i++){
            yo.push_back(yes[i]);
        }
        yes.clear();
        yes=preorderTraversal(root->right);
         for(int i=0;i<yes.size();i++){
            yo.push_back(yes[i]);
        }
        return yo;
    }
    
};