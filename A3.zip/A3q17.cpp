#include<iostream>
using namespace std;

int main() {
    long long x = 0, y = 0;
    string yes1, yes2;
    cin >> yes1 >> yes2;
    long long p = 1;
    for (int i = yes1.length() - 1; i >= 0; i--) {
        x += (yes1[i] - '0') * p;
        p *= 2;
    }
    p = 1;
    for (int i = yes2.length() - 1; i >= 0; i--) {
        y += (yes2[i] - '0') * p;
        p *= 2;
    }
    long long z = x * y;
    cout << z << endl;
    return 0;
}


