class Solution {
public:
    bool toreturn(Node* root, Node* minNode, Node* maxNode) {
        if (!root) return true;

        if ((minNode && root->data <= minNode->data) ||
            (maxNode && root->data >= maxNode->data))
            return false;

        return toreturn(root->left, minNode, root) &&
               toreturn(root->right, root, maxNode);
    }

    bool isBST(Node* root) {
        return toreturn(root, nullptr, nullptr);
    }
};
