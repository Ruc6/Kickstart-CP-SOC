class Solution {
public:
    bool searchMatrix(vector<vector<int>>& matrix, int target) {
        bool found=0;
        int start;
        int end;
        int mid;
        for(int i=0;i<matrix.size();i++){
            start=0;
            end=matrix[i].size()-1;
            while(start<=end){
                mid=start+(end-start)/2;
                if(matrix[i][mid]==target){
                    found=1;
                    break;
                }
                if (target > matrix[i][mid]) {
    start = mid + 1;  
} else {
    end = mid - 1;    
}
            }
            if(found){
                break;
            }
        }
        return found;
    }
};