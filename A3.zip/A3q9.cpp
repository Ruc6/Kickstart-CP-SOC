class Solution {
public:
    vector<int> inorderTraversal(TreeNode* root) {
        vector<int> yo;
        if(root==nullptr){
            return yo;
        }
       
        vector<int> yes;
        yes=inorderTraversal(root->left);
        for(int i=0;i<yes.size();i++){
            yo.push_back(yes[i]);
        }
        yes.clear();
        yo.push_back(root->val);
      
        yes=inorderTraversal(root->right);
         for(int i=0;i<yes.size();i++){
            yo.push_back(yes[i]);
        }
        return yo;
    }
};