class Solution {
public:
    double maxProbability(int n, vector<vector<int>>& edges, vector<double>& succProb, int start_node, int end_node) {
        vector<vector<pair<int, double>>> adj(n); 
        for (int i = 0; i < edges.size(); i++) {
            int u = edges[i][0];
            int v = edges[i][1];
            double prob = succProb[i];
            adj[u].push_back({v, prob});
            adj[v].push_back({u, prob});
        }

        vector<bool> visited(n, false);

      
        priority_queue<pair<double, int>> pq;
        pq.push({1.0, start_node});

        while (!pq.empty()) {
            auto [currProb, node] = pq.top();
            pq.pop();

            if (node == end_node) return currProb;
            if (visited[node]) continue;
            visited[node] = true;

            for (auto [neighbor, edgeProb] : adj[node]) {
                if (!visited[neighbor]) {
                    pq.push({currProb * edgeProb, neighbor}); 
                }
            }
        }

        return 0.0; 
    }
};
