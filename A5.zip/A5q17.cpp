class Solution {
public:

  
    bool boardHasAllLetters(const string& word, const vector<vector<char>>& board) {
        unordered_set<char> boardLetters;
        for (const auto& row : board) {
            for (char ch : row) {
                boardLetters.insert(ch);
            }
        }
        for (char ch : word) {
            if (boardLetters.find(ch) == boardLetters.end())
                return false;
        }
        return true;
    }

   
    bool lessgo(string& word, vector<vector<char>>& board, int i, int j, int count, vector<vector<bool>>& visited) {
        if (board[i][j] != word[count])
            return false;
        if (count == word.size() - 1)
            return true;

        visited[i][j] = true;

      
        vector<int> dx = {-1, -1, -1, 0, 0, 1, 1, 1};
        vector<int> dy = {-1, 0, 1, -1, 1, -1, 0, 1};

        for (int o = 0; o < 8; o++) {
            int nx = i + dx[o];
            int ny = j + dy[o];

            if (nx >= 0 && ny >= 0 && nx < board.size() && ny < board[0].size() && !visited[nx][ny]) {
                if (lessgo(word, board, nx, ny, count + 1, visited)) {
                    visited[i][j] = false; 
                    return true;
                }
            }
        }

        visited[i][j] = false;
        return false;
    }


    bool find(string& word, vector<vector<char>>& board) {
        int rows = board.size();
        int cols = board[0].size();

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (board[i][j] == word[0]) {
                    vector<vector<bool>> visited(rows, vector<bool>(cols, false));
                    if (lessgo(word, board, i, j, 0, visited))
                        return true;
                }
            }
        }
        return false;
    }

   
    vector<string> wordBoggle(vector<vector<char>>& board, vector<string>& dictionary) {
        vector<string> toreturn;
        unordered_set<string> added; 

        for (int i = 0; i < dictionary.size(); i++) {
            string& word = dictionary[i];
            if (added.find(word) != added.end()) continue; 
            if (!boardHasAllLetters(word, board)) continue; 

            if (find(word, board)) {
                toreturn.push_back(word);
                added.insert(word);
            }
        }

        return toreturn;
    }
};