class Solution {
  public:
    int spanningTree(int V, vector<vector<int>> adj[]) {
        vector<bool> visited(V, false);
        priority_queue< pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>> > pq;

        pq.push({0, 0}); 
        int sum = 0;

        while (!pq.empty()) {
            pair<int, int> top = pq.top(); pq.pop();
int wt = top.first;
int u = top.second;

            if (visited[u]) continue;

            visited[u] = true;
            sum += wt;

            for (auto &neighbor : adj[u]) {
                int v = neighbor[0];
                int weight = neighbor[1];
                if (!visited[v]) {
                    pq.push({weight, v});
                }
            }
        }

        return sum;
    }
};