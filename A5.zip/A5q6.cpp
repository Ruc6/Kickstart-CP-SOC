class Solution {
public:
    int minCostConnectPoints(vector<vector<int>>& points) {
        int n = points.size();
        vector<bool> visited(n, false);
        priority_queue< pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>> > pq;
        int result = 0, count = 0;

        pq.push({0, 0}); 

        while (count < n) {
            auto [cost, u] = pq.top(); pq.pop();

            if (visited[u]) continue;

            visited[u] = true;
            result += cost;
            count++;

            for (int v = 0; v < n; v++) {
                if (!visited[v]) {
                    int wt = abs(points[u][0] - points[v][0]) + abs(points[u][1] - points[v][1]);
                    pq.push({wt, v});
                }
            }
        }

        return result;
    }
};
