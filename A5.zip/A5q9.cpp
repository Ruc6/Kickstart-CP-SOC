#include<iostream>
#include<vector>
using namespace std;

int max=0;
for(auto edge:edges){
int temp1=edge[0];
int temp2=edge[1];
if(temp1>max){
max=temp1;
}
else if(temp2>max){
max=temp2;
}}
vector<vector<int>> adj(max,0);
for(auto edge:edges){
adj[edge[0]].pus_back(edge[1],edeg[2]);
adj[edge[1]].pus_back(edge[0],edeg[2]);
}
 int spanningTree(int max, vector<vector<int>> adj[]) {
        vector<bool> visited(max, false);
        priority_queue< pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>> > pq;

        pq.push({0,1}); 
        int sum = 0;

        while (!pq.empty()) {
            pair<int, int> top = pq.top(); pq.pop();
int wt = top.first;
int u = top.second;

            if (visited[u]) continue;

            visited[u] = true;
            sum += wt;

            for (auto &neighbor : adj[u]) {
                int v = neighbor[0];
                int weight = neighbor[1];
                if (!visited[v]) {
                    pq.push({weight, v});
                }
            }
        }

        cout<< sum;
    }
};
