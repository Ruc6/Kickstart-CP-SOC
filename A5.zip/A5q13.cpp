class Solution {
public:
    set<pair<int, int>> visited;

    bool find(int currx, int curry, int x, int y, int target) {
        if (currx == target || curry == target || currx + curry == target) return true;
        if (visited.count({currx, curry})) return false;

        visited.insert({currx, curry});

       
        if (find(x, curry, x, y, target)) return true;

       
        if (find(currx, y, x, y, target)) return true;

        if (find(0, curry, x, y, target)) return true;

       
        if (find(currx, 0, x, y, target)) return true;

       
        int totalXY = currx + curry;
        int newY = min(y, totalXY);
        int newX = totalXY - newY;
        if (find(newX, newY, x, y, target)) return true;

       
        totalXY = currx + curry;
        int newX2 = min(x, totalXY);
        int newY2 = totalXY - newX2;
        if (find(newX2, newY2, x, y, target)) return true;

        return false;
    }

    bool canMeasureWater(int x, int y, int target) {
        if (target > x + y) return false; 
        return find(0, 0, x, y, target);
    }
};