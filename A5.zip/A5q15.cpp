class Solution {
public:
    int networkDelayTime(vector<vector<int>>& times, int n, int k) {
        int sum = 0;
        vector<bool> visited(n, false); 
        vector<vector<pair<int, int>>> adj(n); 
        
       
        for (auto i : times) {
            adj[i[0] - 1].push_back({i[1] - 1, i[2]}); 
        }

        priority_queue< pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>> > pq;
        pq.push({0, k - 1}); 
        vector<int> dist(n, INT_MAX);
        dist[k - 1] = 0;

        while (!pq.empty()) {
            auto t = pq.top(); 
            pq.pop();
            int time = t.first;
            int node = t.second;

            if (visited[node]) continue;
            visited[node] = true;

            for (auto x : adj[node]) {
                int neighbor = x.first;
                int weight = x.second;
                if (!visited[neighbor] && time + weight < dist[neighbor]) {
                    dist[neighbor] = time + weight;
                    pq.push({dist[neighbor], neighbor});
                }
            }
        }

       
        int maxTime = 0;
        for (int i = 0; i < n; i++) {
            if (!visited[i]) return -1;
            maxTime = max(maxTime, dist[i]);
        }

        return maxTime;
    }
};
