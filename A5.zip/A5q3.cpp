class Solution {
  public:
    vector<int> shortestPath(int V, int E, vector<vector<int>>& edges) {
        // code here
        vector<int>dist(V,INT_MAX);
        dist[0]=0;
        for(int i=0;i<V-1;i++){
        for(auto x:edges){
            if(dist[x[0]]!=INT_MAX && dist[x[1]]>dist[x[0]]+x[2]){
                dist[x[1]]=dist[x[0]]+x[2];
            }
        }
    }
    for(int i=0;i<V;i++){
        if(dist[i]==INT_MAX){
            dist[i]=-1;
        }
    }
    return dist;
    }
};
