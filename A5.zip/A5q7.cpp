class Trie {
private:
    Trie* children[26]; 
    bool isEndOfWord;

public:
    Trie() {
           
        isEndOfWord = false;
        for (int i = 0; i < 26; ++i)
            children[i] = nullptr;
    
          
    }

    void insert(string word) {
        Trie* node = this; 
        for (char ch : word) {
            int index = ch - 'a';
            if (!node->children[index])
                node->children[index] = new Trie();
            node = node->children[index];
        }
        node->isEndOfWord = true;
    }

    bool search(string word) {
        Trie* node = this;
        for (char ch : word) {
            int index = ch - 'a';
            if (!node->children[index])
                return false;
            node = node->children[index];
        }
        return node->isEndOfWord;
    }

    bool startsWith(string prefix) {
        Trie* node = this;
        for (char ch : prefix) {
            int index = ch - 'a';
            if (!node->children[index])
                return false;
            node = node->children[index];
        }
        return true;
    }
};
