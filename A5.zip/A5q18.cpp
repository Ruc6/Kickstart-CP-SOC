class Solution {
  public:
    
    bool find(string t, vector<string> &B) {
        for (int k = 0; k < B.size(); k++) {
            if (t == B[k]) return true;
        }
        return false;
    }

    int wordBreak(string A, vector<string> &B) {
      
        if (A == "") return 1;

      
        for (int i = 1; i <= A.size(); i++) {
            string t1 = A.substr(0, i);         
            string t2 = A.substr(i);            

            if (find(t1, B) && wordBreak(t2, B)) {
                return 1;
            }
        }
        return 0;
    }
};