class Solution {
public:
    bool findroute(vector<vector<int>> &adj, int src, int target, vector<bool> &visited) {
        if (src == target) return true;

        visited[src] = true;

        for (int x = 0; x < adj[src].size(); x++) {
            int neighbor = adj[src][x];
            if (!visited[neighbor]) {
                if (findroute(adj, neighbor, target, visited))
                    return true;
            }
        }

        return false;
    }

    bool isBridge(int V, vector<vector<int>> &edges, int c, int d) {
        vector<vector<int>> adj(V);
        
        for (int i = 0; i < edges.size(); i++) {
            int u = edges[i][0];
            int v = edges[i][1];
            if ((u == c && v == d) || (u == d && v == c))
                continue;

            adj[u].push_back(v);
            adj[v].push_back(u);
        }

        vector<bool> visited(V, false);
       
        return !findroute(adj, c, d, visited);
    }
};