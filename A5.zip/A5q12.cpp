class Solution {
public:
    void dfs(int v, int p, vector<vector<int>> &adj, vector<int> &tin, vector<int> &low,
             vector<bool> &vis, int &timer, vector<bool> &isArticulation) {
        vis[v] = true;
        tin[v] = low[v] = timer++;
        int children = 0;

        for (int to : adj[v]) {
            if (to == p) continue;

            if (vis[to]) {
                
                low[v] = min(low[v], tin[to]);
            } else {
                dfs(to, v, adj, tin, low, vis, timer, isArticulation);
                low[v] = min(low[v], low[to]);

                if (low[to] >= tin[v] && p != -1)
                    isArticulation[v] = true;

                ++children;
            }
        }

        if (p == -1 && children > 1)
            isArticulation[v] = true;
    }

    vector<int> articulationPoints(int V, vector<vector<int>> &edges) {
        vector<vector<int>> adj(V);
        for (auto &e : edges) {
            adj[e[0]].push_back(e[1]);
            adj[e[1]].push_back(e[0]);
        }

        vector<int> tin(V, -1), low(V, -1);
        vector<bool> vis(V, false), isArticulation(V, false);
        int timer = 0;

        for (int i = 0; i < V; i++) {
            if (!vis[i])
                dfs(i, -1, adj, tin, low, vis, timer, isArticulation);
        }

        vector<int> result;
for (int i = 0; i < V; i++) {
    if (isArticulation[i])
        result.push_back(i);
}

if (result.empty()) {
    result.push_back(-1); 
}
return result;

    }
};