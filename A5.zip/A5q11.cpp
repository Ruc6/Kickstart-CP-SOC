class Solution {
  public:
    void dfs(int u, vector<int> adj[], vector<int>& disc, vector<int>& low, 
             stack<int>& st, vector<bool>& inStack, int& time, vector<vector<int>>& scc) {
        
        disc[u] = low[u] = time++;
        st.push(u);
        inStack[u] = true;

        for (int v : adj[u]) {
            if (disc[v] == -1) {
                dfs(v, adj, disc, low, st, inStack, time, scc);
                low[u] = min(low[u], low[v]);
            } else if (inStack[v]) {
                low[u] = min(low[u], disc[v]);
            }
        }

        if (low[u] == disc[u]) {
            vector<int> component;
            while (st.top() != u) {
                component.push_back(st.top());
                inStack[st.top()] = false;
                st.pop();
            }
            component.push_back(st.top());
            inStack[st.top()] = false;
            st.pop();
            sort(component.begin(), component.end());
            scc.push_back(component);
        }
    }

    vector<vector<int>> tarjans(int V, vector<int> adj[]) {
        vector<int> disc(V, -1), low(V, -1);
        vector<bool> inStack(V, false);
        stack<int> st;
        vector<vector<int>> scc;
        int time = 0;

        for (int i = 0; i < V; ++i) {
            if (disc[i] == -1) {
                dfs(i, adj, disc, low, st, inStack, time, scc);
            }
        }

        sort(scc.begin(), scc.end()); 
        return scc;
    }
};