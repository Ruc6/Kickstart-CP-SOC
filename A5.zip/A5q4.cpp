class Solution {
  public:
  
    int find(int x, vector<int> &parent) {
        if (parent[x] != x)
            parent[x] = find(parent[x], parent); 
        return parent[x];
    }

    void unite(int u, int v, vector<int> &parent, vector<int> &rank) {
        int pu = find(u, parent);
        int pv = find(v, parent);
        if (pu == pv) return;

        if (rank[pu] < rank[pv])
            parent[pu] = pv;
        else if (rank[pu] > rank[pv])
            parent[pv] = pu;
        else {
            parent[pv] = pu;
            rank[pu]++;
        }
    }

    int kruskalsMST(int V, vector<vector<int>> &edges) {
     
        sort(edges.begin(), edges.end(), [](auto &a, auto &b) {
            return a[2] < b[2];
        });

        vector<int> parent(V), rank(V, 0);
        for (int i = 0; i < V; i++) parent[i] = i;

        int sum = 0;
        for (auto &edge : edges) {
            int u = edge[0], v = edge[1], wt = edge[2];
            if (find(u, parent) != find(v, parent)) {
                sum += wt;
                unite(u, v, parent, rank);
            }
        }

        return sum;
    }
};
