struct WordNode {
    string word;
    WordNode* next;

    WordNode(string w) : word(w), next(nullptr) {}
};

class WordDictionary {
private:
    WordNode* head;

public:
    WordDictionary() {
        head = nullptr;
    }

    void addWord(string newWord) {
        WordNode* node = new WordNode(newWord);
        if (!head) {
            head = node;
        } else {
            WordNode* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = node;
        }
    }

    bool search(string query) {
        WordNode* curr = head;
        while (curr) {
            if (curr->word.size() == query.size()) {
                bool match = true;
                for (int i = 0; i < query.size(); ++i) {
                    if (query[i] != '.' && query[i] != curr->word[i]) {
                        match = false;
                        break;
                    }
                }
                if (match) return true;
            }
            curr = curr->next;
        }
        return false;
    }
};

