class Solution {
public:
    int maxSubArray(vector<int>& nums) {
        
 
     int maxSum = nums[0]; 
     int maxUntil_i = nums[0];    
      for (int i = 1; i < nums.size(); i++) {     
            int x = nums[i];      
               maxUntil_i = max(x, maxUntil_i + x);      
                  maxSum = max(maxSum, maxUntil_i);     }   
                    return maxSum; } 
    
};