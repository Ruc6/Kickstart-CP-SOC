class Solution {
public:
    bool isPalindrome(string s) {
        string forme;
        for (int i = 0; i < s.length(); i++) {
            if (s[i] >= 'A' && s[i] <= 'Z') {
                s[i] = s[i] + 32; 
                forme += s[i];
            } else if (s[i] >= 'a' && s[i] <= 'z') {
                forme += s[i];
            } else if (s[i] >= '0' && s[i] <= '9') {
                forme += s[i];
            }
        }
        int n = forme.size();
        for (int i = 0; i < n / 2; i++) {
            if (forme[i] != forme[n - 1 - i]) {
                return false;
            }
        }

        return true;
    }
};
