class Solution {
public:
    int mySqrt(int x) {
        for(long long  i=0;;i++){
            if(i*i<=x && x<(i+1)*(i+1)){
                return i;
            }
        }
    }
};