class Solution {
public:
    bool isSubsequence(string s, string t) {
        int b = 0;
        for (int i = 0; i < t.length(); i++) {
            if (s[b] == t[i]) {
                b++;
            }
        }
        return b == s.length();
    }
};
