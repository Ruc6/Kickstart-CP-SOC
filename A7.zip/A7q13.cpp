class Solution {
public:
    string longestPalindrome(string s) {
        string pre = "";
        int n = s.size();

        for (int i = 0; i < n; i++) {
            int j = i - 1, k = i + 1;
            string sub(1, s[i]);
            while (j >= 0 && k < n && s[j] == s[k]) {
                sub = s[j] + sub + s[k];
                j--;
                k++;
            }
            if (sub.length() > pre.length()) {
                pre = sub;
            }

            j = i, k = i + 1;
            sub = "";
            while (j >= 0 && k < n && s[j] == s[k]) {
                sub = s[j] + sub + s[k];
                j--;
                k++;
            }
            if (sub.length() > pre.length()) {
                pre = sub;
            }
        }

        return pre;
    }
};
