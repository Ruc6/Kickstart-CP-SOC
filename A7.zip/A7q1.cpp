class Solution {
public:
    vector<int> dp;

    Solution() {
        dp.assign(1001, -1);
    }

    int nthFibonacci(int n) {
        if (n == 0) return 0;
        if (n == 1) return 1;

        if (dp[n] != -1) return dp[n];
        return dp[n] = (nthFibonacci(n - 1) + nthFibonacci(n - 2)) % 1000000007;
    }
};
