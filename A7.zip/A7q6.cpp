class Solution {
public:
vector<int> dp;
    int findMaxSum(vector<int>& arr) {
        dp.assign(arr.size(),-1);
        dp[0]=arr[0];
        dp[1]=max(dp[0],arr[1]);
        for(int i=2;i<arr.size();i++){
      dp[i]=max(dp[i-1],dp[i-2]+arr[i]);
        }
        return dp[arr.size()-1];
    }
};
