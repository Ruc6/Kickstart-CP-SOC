
class Solution {
  public:
  vector<long long> dp;

    Solution() {
        dp.assign(1001, -1);
    }
    int nthTribonacci(int n) {
        // code here
        if (n == 0) return 0;
        if (n == 1) return 1;
        if(n==2) return 1;
        if (dp[n] != -1) return dp[n];
           dp[n] = nthTribonacci(n - 1) + nthTribonacci(n - 2) + nthTribonacci(n - 3);
        return dp[n];
    }
};
