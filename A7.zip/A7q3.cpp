class Solution {
  public:
    vector<long long> dp;

    Solution() {
        dp.assign(1001, -1);
    }

    long long countWays(int n) {
        if (n == 0) return 1;
        if (n == 1) return 1;

        if (dp[n] != -1) return dp[n];

        return dp[n] = countWays(n - 1) + countWays(n - 2);
    }
};
