class Solution {
  public:
    long long maxSum(vector<int>& arr) {
        sort(arr.begin(), arr.end());
        int n = arr.size();
        vector<int> res(n);

        int l = 0, r = n - 1;
        int idx = 0;
        while (l <= r) {
            if (idx < n) res[idx++] = arr[r--];
            if (idx < n) res[idx++] = arr[l++];
        }

        long long sum = 0;
        for (int i = 0; i < n - 1; i++) {
            sum += abs(res[i] - res[i + 1]);
        }
        sum += abs(res[n - 1] - res[0]);

        return sum;
    }
};
