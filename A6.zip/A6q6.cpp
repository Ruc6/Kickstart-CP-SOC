// User function Template for C++
class Solution {
  public:

    int cost(vector<int>& arr) {
        // code here
        int mint=INT_MAX;
        for(int i=0;i<arr.size();i++){
            if(arr[i]<mint){
                mint=arr[i];
            }
        }
        return (arr.size()-1)*mint;
    }
};