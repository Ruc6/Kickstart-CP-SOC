class Solution {
  public:
    int maxStop(int n, int m, vector<vector<int>> &trains) {
        vector<vector<pair<int, int>>> arr(n);

        for (int i = 0; i < m; i++) {
            int arrival = trains[i][0];
            int departure = trains[i][1];
            int platform = trains[i][2] - 1;
            arr[platform].push_back({arrival, departure});
        }

        int sum = 0;

        for (int i = 0; i < arr.size(); i++) {
            if (arr[i].empty()) continue;

           
            sort(arr[i].begin(), arr[i].end(), [](const pair<int, int>& a, const pair<int, int>& b) {
                return a.second < b.second;
            });

            int count = 0;
            int finish = -1;

            for (auto& train : arr[i]) {
                if (train.first >= finish) {
                    count++;
                    finish = train.second;
                }
            }

            sum += count;
        }

        return sum;
    }
};