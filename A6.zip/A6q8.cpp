class Solution {
  public:
    int find(int parent[], int s) {
        if (parent[s] == s) return s;
        return parent[s] = find(parent, parent[s]);
    }

    vector<int> jobSequencing(vector<int> &deadline, vector<int> &profit) {
        int n = deadline.size();
        vector<pair<int, int>> jobs;
        
        for (int i = 0; i < n; i++) {
            jobs.push_back({profit[i], deadline[i]});
        }

        sort(jobs.rbegin(), jobs.rend()); 

        int maxDeadline = *max_element(deadline.begin(), deadline.end());
        int parent[maxDeadline + 1];
        
        for (int i = 0; i <= maxDeadline; i++) {
            parent[i] = i;
        }

        int count = 0, totalProfit = 0;

        for (auto job : jobs) {
            int p = job.first;
            int d = job.second;

            int availableSlot = find(parent, d);
            if (availableSlot > 0) {
                totalProfit += p;
                count++;
                
                parent[availableSlot] = find(parent, availableSlot - 1);
            }
        }

        return {count, totalProfit};
    }
};
