// User function Template for C++

class Solution {
  public:
    // Function to find the minimum number of elements in the first subset.
    int minSubset(vector<int> &arr) {
        // code here
        sort(arr.begin(), arr.end(), greater<int>());
       int t1;
        int t2;
        for (int i = 1; i <= arr.size(); i++) {
            t1=0;
            t2=0;
            for(int j=0;j<i;j++){
                t1+=arr[j];
            }  
        for(int j=i;j<arr.size();j++){
            t2+=arr[j];
        }

          if(t1>t2){
              return i;
          }
        }
        return -1;
    }
    
};