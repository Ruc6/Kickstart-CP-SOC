
class Node {
public:
    char ch;
    int freq;
    int order;
    Node* left;
    Node* right;

    Node(char c, int f, int o) {
        ch = c;
        freq = f;
        order = o;
        left = right = nullptr;
    }
};

struct Compare {
    bool operator()(Node* a, Node* b) {
        if (a->freq == b->freq)
            return a->order > b->order;
        return a->freq > b->freq;
    }
};

class Solution {
public:
    void preorder(Node* root, string code, vector<string>& result) {
        if (!root) return;

        if (!root->left && !root->right) {
            result.push_back(code);
            return;
        }

        preorder(root->left, code + "0", result);
        preorder(root->right, code + "1", result);
    }

    vector<string> huffmanCodes(string S, vector<int> f, int N) {
        priority_queue<Node*, vector<Node*>, Compare> pq;

        for (int i = 0; i < N; i++) {
            pq.push(new Node(S[i], f[i], i));
        }

        int order = N;

        while (pq.size() > 1) {
            Node* a = pq.top(); pq.pop();
            Node* b = pq.top(); pq.pop();

            Node* merged = new Node('#', a->freq + b->freq, order++);

       
            if (a->freq < b->freq) {
                merged->left = a;
                merged->right = b;
            } else if (a->freq > b->freq) {
                merged->left = b;
                merged->right = a;
            } else {
              
                if (a->order < b->order) {
                    merged->left = a;
                    merged->right = b;
                } else {
                    merged->left = b;
                    merged->right = a;
                }
            }

            pq.push(merged);
        }

        Node* root = pq.top();

        vector<string> result;
        preorder(root, "", result);
        return result;
    }
};


