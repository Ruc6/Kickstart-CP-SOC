// class implemented
/*
struct Item{
    int value;
    int weight;
};
*/

class Solution {
  public:
    double fractionalKnapsack(vector<int>& val, vector<int>& wt, int capacity) {
        int n = val.size();
        if (n == 0 || capacity <= 0 || val.size() != wt.size())
            return 0.0;

        vector<vector<double>> fraction(n, vector<double>(3));

        for (int i = 0; i < n; i++) {
            fraction[i][0] = wt[i] != 0 ? (double)val[i] / wt[i] : 0.0;
            fraction[i][1] = val[i];
            fraction[i][2] = wt[i];
        }

        sort(fraction.begin(), fraction.end(), [](vector<double>& a, vector<double>& b) {
            return a[0] > b[0]; 
        });

        double profit = 0.0;
        int currentWeight = 0;

        for (int i = 0; i < n; i++) {
            if (currentWeight + fraction[i][2] <= capacity) {
                currentWeight += fraction[i][2];
                profit += fraction[i][1];
            } else {
                double remain = capacity - currentWeight;
                profit += fraction[i][0] * remain;
                break;
            }
        }

        return round(profit * 1e6) / 1e6;
    }
};

