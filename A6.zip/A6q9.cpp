class Solution {
  public:
    vector<vector<int>> mergeOverlap(vector<vector<int>>& arr) {
        // Code here
        sort(arr.begin(),arr.end());
        vector<vector<int>> toreturn;
        int start=arr[0][0];
        int finish=arr[0][1];
        for(int i=1;i<arr.size();i++){
            if(arr[i][0]<=finish){
                finish=max(finish,arr[i][1]);
            }
            else{
                toreturn.push_back({start,finish});
                start=arr[i][0];
                finish=arr[i][1];
            }
        }
         toreturn.push_back({start,finish});
        return toreturn;
    }
};