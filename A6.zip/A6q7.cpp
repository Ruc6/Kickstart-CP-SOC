class Solution {
  public:
    vector<int> candyStore(int candies[], int N, int K) {
        // Write Your Code here
       sort(candies, candies + N);
        int minm=0;
        int maxm=0;
        int l=0;
        int r=N-1;
        while(l<=r){
            minm+=candies[l];
            l=l+1;
            r-=K;
        }
        l=0;r=N-1;
        while(r>=l){
            maxm+=candies[r];
            r=r-1;
            l+=K;
        }
        vector<int> toreturn;
        toreturn.push_back(minm);
        toreturn.push_back(maxm);
        return toreturn;
    }
};