class Solution {
public:
    bool checkcycle(int node, int parent, vector<bool>& visited, vector<vector<int>>& adj) {
        visited[node] = true;

        for (int neighbor : adj[node]) {
            if (!visited[neighbor]) {
                if (checkcycle(neighbor, node, visited, adj)) return true;
            } else if (neighbor != parent) {
                // Cycle found
                return true;
            }
        }

        return false;
    }

    bool isCycle(int V, vector<vector<int>>& edges) {
        vector<vector<int>> adj(V);
        for (auto& edge : edges) {
            adj[edge[0]].push_back(edge[1]);
            adj[edge[1]].push_back(edge[0]);
        }

        vector<bool> visited(V, false);

        for (int i = 0; i < V; ++i) {
            if (!visited[i]) {
                if (checkcycle(i, -1, visited, adj)) {
                    return true;
                }
            }
        }

        return false;
    }
};
