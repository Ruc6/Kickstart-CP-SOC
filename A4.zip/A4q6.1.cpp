class Solution {
public:
    bool findloop(vector<vector<char>>& grid, vector<vector<int>>& visited, int count, char check, int i, int j, int pi, int pj){
       
        if(i<0 || i>=grid.size() || j<0 || j>=grid[0].size()) return false;

      
        if(grid[i][j] != check) return false;

       
        if(visited[i][j]) {
          
            if(count >= 4) return true;
            else return false;
        }

        visited[i][j] = 1;

        if(i+1 != pi || j != pj)
            if(findloop(grid, visited, count+1, check, i+1, j, i, j)) return true;

        if(i-1 != pi || j != pj)
            if(findloop(grid, visited, count+1, check, i-1, j, i, j)) return true;

        if(i != pi || j+1 != pj)
            if(findloop(grid, visited, count+1, check, i, j+1, i, j)) return true;

        if(i != pi || j-1 != pj)
            if(findloop(grid, visited, count+1, check, i, j-1, i, j)) return true;

        return false;
    }

    bool containsCycle(vector<vector<char>>& grid) {
        int m = grid.size(), n = grid[0].size();
        vector<vector<int>> visited(m, vector<int>(n, 0));

        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                if(!visited[i][j]){
                    if(findloop(grid, visited, 1, grid[i][j], i, j, -1, -1)){
                        return true;
                    }
                }
            }
        }

        return false;
    }
};
