class Solution {
  public:
  vector<int> find(vector<vector<int>> adj,vector<int>&toreturn, vector<bool>& visited, int i,int k){
      if(k==adj.size()-1){
          return toreturn;
      }
       if(visited[i]==0){
                toreturn.push_back(i);
                visited[i]=1;
            }
            for(int j=0;j<adj[i].size();j++){
              
            if(visited[adj[i][j]]==0){
                toreturn.push_back(adj[i][j]);
                visited[adj[i][j]]=1;
            find(adj,toreturn,visited,adj[i][j],k+1);
            }
        }
        return toreturn;
  }
    vector<int> dfs(vector<vector<int>>& adj) {
        // Code here
        vector<int> toreturn;
        vector<bool> visited(adj.size(),0);
        int i=0;
       return find(adj,toreturn,visited,i,0);
          
    
    }
};