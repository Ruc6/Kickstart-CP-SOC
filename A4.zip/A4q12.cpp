class Solution {
  public:

    int dfs(int node, int destination, vector<int> adj[], vector<int>& dp) {
        if (node == destination) return 1;
        if (dp[node] != -1) return dp[node];

        int paths = 0;
        for (int neighbor : adj[node]) {
            paths += dfs(neighbor, destination, adj, dp);
        }

        return dp[node] = paths;
    }

    int countPaths(int V, vector<int> adj[], int source, int destination) {
        vector<int> dp(V, -1);
        return dfs(source, destination, adj, dp);
    }
};
