class Solution {
  public:
  void connectedelements(vector<vector<int>> &image, int i,int j,int colour,int newcolour){
     if(i<0|| i>=image.size()||j<0||j>=image[i].size()||image[i][j]!=colour)return; 
   else{image[i][j]=newcolour;
   connectedelements(image,i+1,j,colour,newcolour);
     connectedelements(image,i-1,j,colour,newcolour);
     connectedelements(image,i,j+1,colour,newcolour);
       connectedelements(image,i,j-1,colour,newcolour);
       
   }   
  }
    vector<vector<int>> floodFill(vector<vector<int>>& image, int sr, int sc,
                                  int newColor) {
        // Code here
        int colour=image[sr][sc];
           if(colour == newColor) return image;
       connectedelements(image,sr,sc,colour,newColor);
        return image;
    }
};