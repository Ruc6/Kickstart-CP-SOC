class Solution {
public:
   
    vector<int> reshuffle(vector<int>& to, vector<int>& adj, int x) {
        int o = to[x];
        int toexchange = x;

        for (int j = 0; j < x; j++) {
            for (int k = 0; k < adj.size(); k++) {
                if (to[j] == adj[k]) {
                    toexchange = j;
                }
            }
        }
        int temp = to[x];
        to[x] = to[toexchange];
        to[toexchange] = temp;

        return to;
    }

    vector<int> topoSort(int V, vector<vector<int>>& edges) {
        vector<vector<int>> adj(V);
        for (auto& pair : edges) {
            adj[pair[0]].push_back(pair[1]);
        }

        vector<int> to;
        for (int i = 0; i < V; i++) {
            to.push_back(i);
        }

        for (int i = 0; i < V; i++) {
            int x = 0;
            for (int l = 0; l < V; l++) {
                if (to[l] == i) {
                    x = l;
                    break;
                }
            }
            to = reshuffle(to, adj[i], x);
        }

        return to;
    }
};
