class Solution {
  public:
    
    vector<int> bfs(vector<vector<int>> &adj) {
        // Code here
        vector<bool> visited(adj.size(),0);
        vector<int> toreturn;
        toreturn.push_back(0);
        visited[0]=1;
        for(int i=0;i<toreturn.size();i++){
            for(int j=0;j<adj[toreturn[i]].size();j++){
                if(visited[adj[toreturn[i]][j]]==0){
                    visited[adj[toreturn[i]][j]]=1;
                    toreturn.push_back(adj[toreturn[i]][j]);
                }
            }
        }
        return toreturn;
    }
};