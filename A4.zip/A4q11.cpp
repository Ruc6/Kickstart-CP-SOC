class Solution {
public:
    int minThrow(int N, int arr[]) {
        vector<int> board(31, -1);  
        for (int i = 0; i < N; i++) {
            int u = arr[2 * i];
            int v = arr[2 * i + 1];
            board[u] = v;
        }

        vector<bool> visited(31, false);
        queue<pair<int, int>> q;  
        q.push({1, 0});
        visited[1] = true;

        while (!q.empty()) {
            int cell = q.front().first;
            int dist = q.front().second;
            q.pop();

            if (cell == 30)
                return dist;

            for (int dice = 1; dice <= 6; dice++) {
                int next = cell + dice;
                if (next > 30) continue;

                if (board[next] != -1)
                    next = board[next];

                if (!visited[next]) {
                    visited[next] = true;
                    q.push({next, dist + 1});
                }
            }
        }

        return -1;  
    }
};
