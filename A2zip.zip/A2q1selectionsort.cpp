//Time O(n^2)
//space O(n^2)
#include<iostream>
#include<vector>
using namespace std;
vector<int> selectionsort(vector<int> arr, int begin, int size){
if(begin==size-1){
return arr;
}
int mini=arr[begin];
int j=begin;
for(int i=begin; i<size;i++){
if(arr[i]<mini){
j=i;
mini=arr[i];
}
}
swap(arr[begin],arr[j]);
return selectionsort(arr,begin+1,size);
}
void letssort(int size){
vector<int>final(size);
for(int j=0; j<size; j++){
cin>>final[j];
}
final=selectionsort(final,0,size);
for(int j=0; j<size; j++){
cout<<final[j]<<" ";
}
cout<<endl;
}
int main(){
int n;
cin>>n;
int size;
for(int i=0;i<n;i++){
cin>>size;
letssort(size);
}
return 0;
}