//Time O(n^2)
//space O(1)
#include<iostream>
#include<vector>
using namespace std;
void letssort(int size){
vector<int>final(size);
for(int j=0; j<size; j++){
cin>>final[j];
}
int n = final.size();
for(int i = 1; i < n; i++) {
int key =final[i];
int j = i - 1;
 while(j >= 0 && final[j] > key) {
 final[j + 1] = final[j];
 j--;
 }
 final[j + 1] = key;
}
for(int j=0; j<size; j++){
cout<<final[j]<<" ";
}
cout<<endl;
}
int main(){
int n;
cin>>n;
int size;
for(int i=0;i<n;i++){
cin>>size;
letssort(size);
}
return 0;
}