//timeO(n)
//spaceO(n)
#include<iostream>
#include<vector>
using namespace std;

void letssort(int size) {
    vector<int> final(size);
    for(int j = 0; j < size; j++) {
        cin >> final[j];
    }

    int mid = (size - 1) / 2;
    int left = 0;
    int right = mid + 1;

    vector<int> Y;  // Result of merge

    while (left <= mid && right < size) {
        if (final[left] <= final[right]) {
            Y.push_back(final[left++]);
        } else {
            Y.push_back(final[right++]);
        }
    }

    // Append remaining elements
    while (left <= mid) {
        Y.push_back(final[left++]);
    }
    while (right < size) {
        Y.push_back(final[right++]);
    }

    // Output
    for (int j = 0; j < Y.size(); j++) {
        cout << Y[j] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    cin >> n;
    int size;
    for(int i = 0; i < n; i++) {
        cin >> size;
        letssort(size);
    }
    return 0;
}
