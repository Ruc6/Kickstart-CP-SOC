class Solution {
public:
    vector<int> sortByBits(vector<int>& arr) {
        vector<int> final;
        sort(arr.begin(), arr.end());
        vector<vector<int>> ar(32); 
        for (int i = 0; i < arr.size(); i++) {
            int x = arr[i]; 
            int count = 0;
            while (x) {
                count += x & 1;
                x >>= 1;
            }
            ar[count].push_back(arr[i]); 
        }

        for (int i = 0; i < ar.size(); i++) {
            for (int j = 0; j < ar[i].size(); j++) {
                final.push_back(ar[i][j]);
            }
        }

        return final;
    }
};