//timeO(n^2)
//spaceO(1)
#include<iostream>
#include<vector>
using namespace std;
void letssort(int size){
vector<int>final(size);
for(int j=0; j<size; j++){
cin>>final[j];
}
for(int k=0;k<size;k++){
for(int i=0;i<size-1;i++){
if(final[i]>final[i+1]){
swap(final[i],final[i+1]);
}
}
}
for(int j=0; j<size; j++){
cout<<final[j]<<" ";
}
cout<<endl;
}
int main(){
int n;
cin>>n;
int size;
for(int i=0;i<n;i++){
cin>>size;
letssort(size);
}
return 0;
}