class Solution {
public:
    vector<int> intersection(vector<int>& nums1, vector<int>& nums2) {
        vector<int> nums3;
        int c;
        for(int x=0; x<nums1.size();x++){
            for(int y=0; y<nums2.size();y++){
                if(nums1[x]==nums2[y]){
                    c=0;
                for(int z=0; z<nums3.size();z++){
                    if(nums3[z]==nums2[y]){
                        c=1;
                        break;
                    }
                }
                if(c==0){
                    nums3.push_back(nums2[y]);
                }
                }
            }
        }
        return nums3;
    }
};